package day2;

// 	(1) 8진수 정수 리터럴을 사용하여, 7, 14, 21을 출력.  07 016 025 
//  (2) 16진수 정수 리터럴을 사용하여, 7, 14, 21을 출력. 0x7 0xe 0x15

public class Ex206 {
	public static void main(String[] args) {
		System.out.println(07 + " " + 016 + " " + 025);
		System.out.println(0x7 + " " + 0xe + " " + 0x15);
	}
}







