package day2;

// Ex202 : 정수리터럴 (2진수(0b...), 8진수(0...), 16진수(0x...))
public class Ex202 {
	public static void main(String[] args) {
		int num = 0b11;
		System.out.println(num);   // 3
	}
}









