package day2;

public class Ex214 {
	public static void main(String[] args) {
		System.out.println(1 & 3);
		System.out.println(0b0001 & 0b0011);  // 0b____
		System.out.println(5 & 12);
		System.out.println(0b0101 & 0b1100);  // 0b____
	}
}