package day2;

import java.util.Scanner;

//Ex210. 연습.
//- 3개의 정수를 입력받고, 이 중에서 최대값을 출력.
//- 단, 조건문(if) 사용x.
public class Ex210 {					
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("a : ");
		int a = sc.nextInt();
		System.out.print("b : ");
		int b = sc.nextInt();
		System.out.print("c : ");
		int c = sc.nextInt();

//		int max = ______________________________;
//		System.out.println("max : " + max);
//		int min = ______________________________;
//		System.out.println("min : " + min);
	}
}












