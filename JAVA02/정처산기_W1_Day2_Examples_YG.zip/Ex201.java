package day2;

public class Ex201 {
	public static void main(String[] args) {
		int v1 = 9;
		float v2 = 8.9f;
		double v3 = 9.15;
		boolean v4 = false;
		String v5 = "A String.";
		
		System.out.println(v1);
		System.out.println(v2);
		System.out.println(v3);
		System.out.println(v4);
		System.out.println(v5);
	}
}





