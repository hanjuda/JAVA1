package day2;

public class Test {
	public static void main(String[] args) {
		byte b = -3;     // 11111101 
		System.out.println(~b);	 // 2
	}
}





